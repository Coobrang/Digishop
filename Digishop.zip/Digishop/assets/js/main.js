let select = document.getElementById("select");
let list = document.getElementById("list");
let selectText = document.getElementById("selectText");
let options = document.getElementsByClassName("options");

select.onclick = function(){
    list.classList.toggle("open");
}

for(options of options){
    options.onclick = function(){
        selectText.innerHTML = this.innerHTML;
    }
}